<h1 align="center"> 𝐃𝐄𝐕_𝐌𝐀𝐗-𝐌𝐃 </h1>

<img align="center" height="auto"
src="https://files.catbox.moe/tx03aw.png">

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=506EF8&lines=WELCOME+TO+DEV+MAX+MD+MADE+BY;JELIO+STARR+DEV;THANKS+FOR+VISITING+MY+REPO)](https://git.io/typing-svg)
<br>

   </p>
<p align="center">
<a href="https://github.com/Jeliostarr"><img title="Author" src="https://img.shields.io/badge/DEV-blue?style=for-the-badge&logo=Github"></a> <a href="https://youtube.com/@dev_hosting"><img title="Author" src="https://img.shields.io/badge/YT CHANNEL-darkred?style=for-the-badge&logo=youtube"></a> <a href="https://wa.me/256707934960"><img title="Author" src="https://img.shields.io/badge/Contact Me-darkgreen?style=for-the-badge&logo=whatsapp"></a>
<p/> 

 <p align="center">
<a href="https://github.com/Jeliostarr/followers"><img title="Followers" src="https://img.shields.io/github/followers/Jeliostarr?color=purple&style=flat-square"></a>
<a href="https://github.com/Jeliostarr/DEV_MAX-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Jeliostarr/DEV_MAX-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Jeliostarr/DEV_MAX-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Jeliostarr/DEV_MAX-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Jeliostarr/DEV_MAX-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Jeliostarr/DEV_MAX-MD?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/Jeliostarr/DEV_MAX-MD/"><img title="Size" src="https://img.shields.io/github/repo-size/Jeliostarr/DEV_MAX-MD?style=flat-square&color=green"></a>
<a href="https://github.com/Jeliostarr/DEV_MAX-MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;</a>
<p align="center"><img src="https://profile-counter.glitch.me/{DEV_MAX-MD}/count.svg" alt="Jeliostarr :: Visitor's Count" old_src="https://profile-counter.glitch.me/{Jeliostarr}/count.svg" /></p>
<p align="center">
<a href="https://github.com/Jeliostarr/DEV_MAX-MD"Dev"><img title="PUBLIC-BOT" src="https://img.shields.io/static/v1?label=Language&message=English&style=flat-square&color=darkpink"></a> &nbsp;
  <img src="https://komarev.com/ghpvc/?username=Jeliostarr&label=VIEWS&style=flat-square&color=blue" />
</a>
<p align="center">
  <a href="https://github.com/Jeliostarr/DEV_MAX-MD"><img title="Release" src="https://img.shields.io/badge/Release-beta%20v1.0.0-darkcyan.svg?style=for-the-badge&logo=appveyor" /></a>

<p align='center'>
    </p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<p align="center">
    <strong>FORK REPOSITORY</strong>
  <br>
    <a href="https://github.com/Jeliostarr/DEV_MAX-MD/fork" target="_blank">
        <img alt="Fork Repo" src="https://img.shields.io/badge/Fork%20Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkblue"/>
    </a>
</p>

<p align="center">
    <strong>TUTORIALS & DEPLOYMENTS</strong>
    <br>
    <a href="https://www.jeliostarrdev.space/" target="_blank">
        <img alt="WEBSITE" src="https://img.shields.io/badge/Get%20Started-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkred&color=darkred"/>
    </a>
</p>

</details>

## Credits

- [Dev](https://github.com/Jeliostarr)
- [Hector](https://github.com/OfficialKango)
- [Baileys](https://github.com/WhiskeySockets)

<h2 align="center">  𝗣𝗢𝗟𝗜𝗧𝗘 𝗡𝗢𝗧𝗜𝗖𝗘!
</h2>

- This bot is made for educational purposes `only` hence `DO NOT MISUSE`.

**© 𝘿𝙀𝙑 𝙎𝙋𝘼𝘾𝙀**
##

<a><img src='https://i.imgur.com/LyHic3i.gif'/>
